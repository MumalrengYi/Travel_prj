package command;

public class CouponCommand {
	String cpNo;
	String cpDiscount;
	String prodNo;
	public String getCpNo() {
		return cpNo;
	}
	public void setCpNo(String cpNo) {
		this.cpNo = cpNo;
	}
	public String getCpDiscount() {
		return cpDiscount;
	}
	public void setCpDiscount(String cpDiscount) {
		this.cpDiscount = cpDiscount;
	}
	public String getProdNo() {
		return prodNo;
	}
	public void setProdNo(String prodNo) {
		this.prodNo = prodNo;
	}
	
	
	
}
