package command;


public class OrderTravelCommand {

	String prodNo;
	String orderNo;
	String orderCount;
	String hotelMealPax;
	String hotelBed;
	String orderTotalPrice;
	public String getProdNo() {
		return prodNo;
	}
	public void setProdNo(String prodNo) {
		this.prodNo = prodNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(String orderCount) {
		this.orderCount = orderCount;
	}
	public String getHotelMealPax() {
		return hotelMealPax;
	}
	public void setHotelMealPax(String hotelMealPax) {
		this.hotelMealPax = hotelMealPax;
	}
	public String getHotelBed() {
		return hotelBed;
	}
	public void setHotelBed(String hotelBed) {
		this.hotelBed = hotelBed;
	}
	public String getOrderTotalPrice() {
		return orderTotalPrice;
	}
	public void setOrderTotalPrice(String orderTotalPrice) {
		this.orderTotalPrice = orderTotalPrice;
	}

}
