package Model;

public class ProductWishDTO {
	ProductDTO productDTO;
	WishDTO wishDTO;
	
	
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public WishDTO getWishDTO() {
		return wishDTO;
	}
	public void setWishDTO(WishDTO wishDTO) {
		this.wishDTO = wishDTO;
	}
}
